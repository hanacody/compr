class <?php echo $Tbl;?>_model_test extends Controller
{
	function <?php echo $Tbl;?>_model_test()
	{
		parent::Controller();
		// Unit Test Library Load
		$this->load->library('unit_test');

		// <?php echo $tbl;?> Model Load
		$this->load->model('<?php echo $tbl;?>_model');
	}
	
	function index()
	{
		$this->get_<?php echo $tbl;?>_count_test();
		if($this->add_<?php echo $tbl;?>_test()) {
			$this->get_<?php echo $tbl;?>_test();
			if($this->edit_<?php echo $tbl;?>_test())
				$this->delete_<?php echo $tbl;?>_test();
		}
	}

	function add_<?php echo $tbl;?>_test()
	{
		$ret = FALSE;

		if($this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key;?>' => '<?php echo $primary_value;?>')) == 0) {
			$row = array(
				'<?php echo $primary_key;?>' => '<?php echo $primary_value;?>'
			);

			$this-><?php echo $tbl;?>_model->add_<?php echo $tbl;?>($row);
			echo $this->unit->run(
				$this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key; ?>' => '<?php echo $primary_value;?>')),
				1,
				'<?php echo $tbl;?> Add test');
			if($this->_get_test_result('c_board Add test') == 'Passed') $ret = TRUE;
		} else {
			echo "�̹� ������� Primary Key �Դϴ�.<br/>���� �� �ٽ� �׽�Ʈ �Ͽ� �ֽʽÿ�.";
		}

		return $ret;
	}

	function get_<?php echo $tbl;?>_test()
	{
		echo $this->unit->run(
			count($this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>('<?php echo $primary_value;?>')) > 0,
			TRUE,
			'<?php echo $tbl;?> Get test');
	}

	function get_<?php echo $tbl;?>_count_test()
	{
		echo $this->unit->run(
			$this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count() > 0,
			TRUE,
			'<?php echo $tbl;?> Get Count test');
	}

	function edit_<?php echo $tbl;?>_test()
	{
		$ret = FALSE;

		if($this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key; ?>' => '<?php echo $primary_value + 1;?>')) == 0) {
			$row = array(
				'<?php echo $primary_key;?>' => '<?php echo $primary_value + 1;?>'
			);

			$this-><?php echo $tbl;?>_model->edit_<?php echo $tbl;?>('<?php echo $primary_value;?>', $row);
			echo $this->unit->run(
				$this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key; ?>' => '<?php echo $primary_value + 1;?>')),
				1,
				'<?php echo $tbl;?> Edit test');

			if($this->_get_test_result('c_board Edit test') == 'Passed') $ret = TRUE;
		} else {
			echo "�̹� ������� Primary Key �Դϴ�.<br/>���� �� �ٽ� �׽�Ʈ �Ͽ� �ֽʽÿ�.";
		}

		return $ret;
	}

	function delete_<?php echo $tbl;?>_test()
	{
		$this-><?php echo $tbl;?>_model->delete_<?php echo $tbl;?>('<?php echo $primary_value + 1;?>');
		echo $this->unit->run(
			$this-><?php echo $tbl;?>_model->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key; ?>' => '<?php echo $primary_value + 1;?>')),
			0,
			'<?php echo $tbl;?> Delete test');
	}

	function _get_test_result($test_name = NULL)
	{
		$ret = FALSE;
		
		if($test_name !== NULL) {
			foreach ($this->unit->result() as $res) {
				if($res['Test Name'] == $test_name) {
					$ret = $res['Result'];
					break;
				}
			}
		}
		
		return $ret;
	}
}
/* End of file <?php echo $tbl;?>_model_test.php */
/* Create By CodeIgniter Korea Forum (hoksi-����ȸ��) */