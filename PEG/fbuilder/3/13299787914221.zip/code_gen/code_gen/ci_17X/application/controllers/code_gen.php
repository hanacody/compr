<?php
class Code_gen extends Controller {

	var $data;
	
	function Code_gen()
	{
		parent::Controller();

		$this->load->model('code_gen_model');
	}
	
	function index()
	{
		$this->code_generate();
	}
	
	function code_generate($tbl = NULL, $primary_key = NULL, $primary_value = 1, $type = 'model', $download = FALSE)
	{
		$tbl_info = $this->code_gen_model->get_table_info($tbl);
		$this->data['tbl'] = '';
		$this->data['tbl_list'] = $this->code_gen_model->get_table_list();
		$this->data['field_list'] = $this->code_gen_model->get_field_list($tbl);
				
		if($tbl_info) {
			$this->data = array(
				'tbl_list' => $this->data['tbl_list'],
				'field_list' => $this->data['field_list'],
				'tbl' => $tbl, 
				'Tbl' => ucfirst($tbl),
				'tbl_info' => $tbl_info,
				'primary_key' => $primary_key == NULL ? $this->_get_primary_key($tbl_info) : $primary_key,
				'primary_value' => $primary_value
			);
			
			$this->data['model_code'] = $this->_model_code_gen();
			$this->data['test_code'] = $this->_test_code_gen();
		}

		if($download === 'download') {
			$file_name = $tbl . '_model' . ($type == 'test' ? '_test' : '') . '.php';
			$this->_download($file_name, ($type == 'test' ? $this->data['test_code'] : $this->data['model_code']));
		} else {
			$this->load->view('code_gen/index', $this->data);
		}
	}

	function _download($file_name = NULL, $data = NULL)
	{
		$this->load->helper('download');
		
		if($file_name !== NULL && $data !== NULL) {
			$data = "<?php\r\n" . $data;
			force_download($file_name, $data);
		}
	}
	
	function _test_code_gen()
	{
		return $this->load->view('code_gen/test_code', $this->data, TRUE);
	}
	
	function _model_code_gen()
	{
		return $this->load->view('code_gen/model_code', $this->data, TRUE);
	}
	
	function _get_primary_key($tbl_info)
	{
		$ret = 'id';
		
		foreach ($tbl_info as $col) {
			if($col->primary_key == 1){
				$ret = $col->name;
				break;
			}
		}
		
		return $ret;
	}
	
}