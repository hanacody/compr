<?php $this->load->helper('form');?>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=EUC-KR"/>
<title>CI Model Code Generators</title>
<link href="http://alexgorbatchev.com/pub/sh/current/styles/shCore.css" rel="stylesheet" type="text/css" />
<link href="http://alexgorbatchev.com/pub/sh/current/styles/shThemeDefault.css" rel="stylesheet" type="text/css" />
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/themes/ui-lightness/jquery-ui.css" rel="stylesheet" type="text/css" />
<script src="http://alexgorbatchev.com/pub/sh/current/scripts/shCore.js" type="text/javascript"></script>
<script src="http://alexgorbatchev.com/pub/sh/current/scripts/shAutoloader.js" type="text/javascript"></script>
<script src="http://alexgorbatchev.com/pub/sh/current/scripts/shBrushPhp.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
<script type="text/javascript">
	$(function(){
		SyntaxHighlighter.config.bloggerMode = true;
		SyntaxHighlighter.all();
		$("#main_dialog").dialog({
			sticky: true,
			width:600,
			show: "drop",
			hide: "drop",
			position: ['left', 'top']
		});
		$("#make_btn").button();
		$("#win_btn").button();
	});

	function select_tbl(tbl)
	{
		location.href='/code_gen/code_generate/' + tbl;
	}

	function code_gen()
	{
		location.href='/code_gen/code_generate/<?php echo $tbl;?>/' + $('#pkey').val() + '/' + $('#pVal').val(); 
	}
</script>
</head>
<body>
<input type="button" value="Code Generator" id="win_btn" onclick="$('#main_dialog').dialog('open');" style="font-size:12px" />
<div id="main_dialog" Title="Code Generator">
<table style="font-size:12px; width:100%">
<tr>
	<th>Table</th>
	<td><?php echo form_dropdown('table', $tbl_list, $tbl, 'id="table" onchange="select_tbl(this.value)"');?></td>
	<td>* ���̺��� ������ �ּ���.</td>
</tr>
<?php if($field_list):?>
<tr>
	<th>Primary Key</th>
	<td><?php echo form_dropdown('pkey', $field_list, $primary_key, 'id="pkey"');?></td>
	<td>* Primary Key�� ������ �ּ���.</td>
</tr>
<tr>
	<th>Value</th>
	<td><input type="text" name="pVal" id="pVal" size="8" value="<?php echo $primary_value;?>" /></td>
	<td>* �׽�Ʈ�ڵ忡�� ����� ���� ������ �ּ���.</td>
</tr>
<tr>
	<td colspan="3"><hr/><input id="make_btn" type="button" value="Model Code ����" onclick="code_gen()" /></td>
</tr>
<?php endif;?>
</table>
<hr/>
DownLoad : 
<?php if(isset($model_code)):?>
<a href="/code_gen/code_generate/<?php echo $tbl . '/' . $primary_key . '/' . $primary_value . '/model/download';?>">model code</a>
<?php endif;?>

<?php if(isset($test_code)):?>
<a href="/code_gen/code_generate/<?php echo $tbl . '/' . $primary_key . '/' . $primary_value . '/test/download';?>">test code</a>
<?php endif;?>

</div>
<div>

<?php if(isset($model_code)):?>
<pre title="models/<?php echo $tbl;?>_model.php" class="brush: php;" id="model_code" style="width:80%">
&lt;?php
<?php echo $model_code;?>
</pre>
<?php endif;?>

<?php if(isset($test_code)):?>
<pre title="controls/<?php echo $tbl;?>_model_test.php" class="brush: php;" id="model_code">
&lt;?php
<?php echo $test_code;?>
</pre>
<?php endif;?>
</div>
</body>
</html>