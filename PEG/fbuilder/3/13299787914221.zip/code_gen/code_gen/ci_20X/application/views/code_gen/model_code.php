class <?php echo $Tbl;?>_model extends CI_Model
{
    
    function __construct()
    {
        parent::__construct();
        
        $this->load->database();
    }
    
	function find_<?php echo $tbl;?>($where = NULL, $select = '*', $limit = 1000)
	{
		$this->db->select($select);
		$this->db->from('<?php echo $tbl;?>');
		if($where !== NULL) $this->db->where($where);
		if($limit !== NULL) $this->db->limit($limit);
		$rs = $this->db->get();

		return $rs->result_array();
	}

	function get_<?php echo $tbl;?>($id = NULL, $select = '*', $limit = NULL)
	{
	   $ret = NULL;

		if($id !== NULL) {
			$ret = $this->find_<?php echo $tbl;?>(array('<?php echo $primary_key;?>' => $id), $select, $limit);
		}

		return $ret;
	}

	function get_<?php echo $tbl;?>_count($where = NULL)
	{
		$ret = -1;

		if($where !== NULL) {
			$this->db->where($where);
		}

		$res = $this->db->count_all_results('<?php echo $tbl;?>');
		$ret = isset($res['numrows']) ? $res['numrows'] : $ret;

		return $ret;
	}

	function add_<?php echo $tbl;?>($row = NULL)
	{
		$ret = FALSE;

		if($row !== NULL && is_array($row) && !empty($row)) {
			// $row['created'] = date('Y-m-d H:i:s');

			$this->db->insert('<?php echo $tbl;?>', $row);

			$ret = TRUE;
		}

		return $ret;
	}

	function edit_<?php echo $tbl;?>($id = NULL, $row = NULL)
	{
		$ret = FALSE;

		if($id !== NULL && $row !== NULL && is_array($row) && !empty($row) &&
		   $this->get_<?php echo $tbl;?>_count(array('<?php echo $primary_key;?>' => $id)) == 1
		) {
			// $row['updated'] = date('Y-m-d H:i:s');

			$this->db->where('<?php echo $primary_key;?>', $id);
			$this->db->update('<?php echo $tbl;?>', $row);

			$ret = TRUE;
		}

		return $ret;
	}

	function delete_<?php echo $tbl;?>($id = NULL)
	{
 		$ret = FALSE;

		if($id !== NULL) {
			$this->db->where('<?php echo $primary_key;?>', $id);
			$this->db->delete('<?php echo $tbl;?>');

			$ret = TRUE;
		}

		return $ret;
	}
}
/* End of file <?php echo $tbl;?>_model.php */
/* Create By CodeIgniter Korea Forum (hoksi-����ȸ��) */